export RDS_HOSTNAME='autobank-mysql.c66tbaq3niik.us-east-1.rds.amazonaws.com';
export RDS_PORT='3306';
export RDS_DB_NAME='autobankdb';
export RDS_USERNAME='admin';
export RDS_PASSWORD='ilovebaboo';
export GMAIL_USERNAME='abababa.robot@gmail.com';
export GMAIL_PASSWORD='ilovebaboo';